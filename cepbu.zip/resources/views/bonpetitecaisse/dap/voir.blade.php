@extends('layout/app')
@section('page-content')
@php
    $cryptedId = Crypt::encrypt($data->id);
@endphp
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12" style="margin:auto">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0"><i class="fa fa-folder-plus"></i> Le details de la DAP (N° {{ $data->numerodap  }} ) </h4>
                        <div class="page-title-right" >

                          <!--  @if($data->	etablie_aunom==1)
                            <div class="spinner-grow text-danger " role="status" style=" 
                        width: 0.9rem; /* Définissez la largeur */
                        height: 0.9rem; /* Définissez la hauteur */" title="Signaler le DAP en cas d'erreur ">
                                <span class="sr-only">Loading...</span>
                            </div> &nbsp; &nbsp;
                            @endif


                            <button type="button" class="btn btn-danger waves-effect waves-light" data-bs-toggle="modal" data-bs-target="#composemodal" data-dapid="{{ $data->id ? $data->id : '' }}" title="Signaler le DAP en cas d'erreur ">
                                <i class="fab fa-telegram-plane ms-1"></i> Signalé DAP
                            </button>

-->
                            &nbsp; &nbsp;


                            <div class="btn-toolbar float-end" role="toolbar">
                                <div class="btn-group me-2 mb-2 mb-sm-0">
                                    <!--<a href="{{ route('generate-pdf-dap',$cryptedId  ) }}" class="btn btn-primary waves-light waves-effect" title="Générer PDF "><i class="fa fa-print"></i> </a> -->
                                    <a href="{{ route('showdappc', $cryptedId ) }}" class="btn btn-primary waves-light waves-effect" title="Modifier le DAP"><i class="fa fa-edit"></i> </a>
                                    <a href="{{ route('dappc') }}" class="btn btn-primary waves-light waves-effect" title="Liste de DAP "><i class="fa fa-list"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="invoice-title">
                       
                            <div class="text-muted">
                            <table class="table  table-sm fs--1 mb-0 ">
                                    <tr>
                                        <td style=" width:10% ;" align="right"> 
                                            <img src="{{ asset('element/logo/logo.png') }}" alt="logo" height="50" /> </td>
                                        <td>
                                            <center>
                                            <p class="mb-1">
                                                <h3>{{ $dateinfo->entete }}</h3>
                                            </center>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <center>{{ $dateinfo->sousentete }}</center>
                                        </td>
                                    </tr>
                                </table>


                            </div>
                    </div>
                    <br>
                    <div class="row">
                        <H5>
                            <center> 
                                Demande d'Autorisation de Paiement (DAP) N° {{  $data->numerodap  }}/{{ $year }}
                            </center>
                        </H5>

                        <div class="col-sm-12">
                            <table class="table table-striped table-sm fs--1 mb-0 table-bordered  ">
                                <tr>
                                    <td style= "width:55%"> Service: {{ $data->titres }}</td>
                                    <td>
                                        Référence: FEB n<sup>o</sup>:
                                        @php
                                        foreach ($datafebElement as $key => $datafebElements) {
                                        echo '['.$datafebElements->referencefeb.']';

                                        if ($key < count($datafebElement) - 1) { echo ',' ; } } @endphp </td>
                                </tr>
                                <tr>
                                    <td> Composante/ Projet/Section: {{ $data->projettitle }}</td>
                                    <td> Lieu: {{ $data->lieu }} </td>
                                </tr>

                                <tr>
                                    <td> 
                                    <table>
                                            <td>
                                                <label title="OV"> &nbsp; Moyen de Paiement : OV </label>
                                            </td>
                                            <td>
                                                <input type="checkbox" readonly @if($data->ov==1) checked @else @endif />
                                            </td>
                                            <td> &nbsp; &nbsp; &nbsp; &nbsp; Cheque: {{ $data->cho }} ; Etabli au nom : {{ $data->etablie_aunom}}</td>
                                        </table>
                                    </td>
                                    <td> Compte bancaire : {{ $data->comptebanque }} ; Banque : {{ $data->banque }}</td>
                                </tr>

                                <tr>
                                    <td></td>
                                    <td>  </td>
                                </tr>

                               
                                <tr>
                                    <td>
                                    Créé le {{ date('d-m-Y', strtotime($data->created_at))  }}
                                    </td>
                                    <td>  Taux d’exécution globale du projet: %   </td>
                                </tr>

                            </table>
                            <br>
                    </div>


                </div>
            </div>

<!-- ici -->
        </div>
    </div>
    <br>
    <br>
</div>
</div>

<!-- ici -->


@include('document.dap.modale_feb')

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function openPopup(element) {
        // Récupérer l'URL du document à ouvrir
        var documentUrl = element.getAttribute('data-document-url');

        // Définir les dimensions de la fenêtre popup
        var width = screen.width * 0.7; // 50% de la largeur de l'écran
        var height = screen.height * 0.7; // 50% de la hauteur de l'écran

        // Calculer les coordonnées pour centrer la fenêtre popup
        var left = (screen.width - width) / 2;
        var top = (screen.height - height) / 2;

        // Définir les options de la fenêtre popup
        var options = 'width=' + width + ',height=' + height + ',top=' + top + ',left=' + left + ',resizable=yes,scrollbars=yes';

        // Ouvrir la fenêtre popup
        window.open(documentUrl, 'Document', options);
    }
</script>


@endsection