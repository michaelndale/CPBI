@extends('layout/app')
@section('page-content')
<div class="content">
  <div class="row">
    <div class="col-xl-12" >

    <div class="row g-3 justify-content-between align-items-center">
      <div class="col-7 col-md">
        <h4 class="text-900 mb-0" data-anchor="data-anchor"><i class="fa fa-folder-open "></i>BON DE PETITE CAISSE </h4>
      </div>
      <div class="col col-md-auto">
      <nav class="nav nav-underline justify-content-end doc-tab-nav align-items-center" role="tablist">
      
      @include('document.bpc.modale')
      
      </nav>
    </div>

  
    <div id="tableExample2" data-list="{&quot;valueNames&quot;:[&quot;name&quot;,&quot;email&quot;,&quot;age&quot;],&quot;page&quot;:5,&quot;pagination&quot;:{&quot;innerWindow&quot;:2,&quot;left&quot;:1,&quot;right&quot;:1}}">
      <div class="table-responsive">
        <table class="table table-striped table-sm fs--1 mb-0">
          <thead>
                              <tr>
                                <th class="sort border-top ps-3" data-sort="name">Titre</th>
                                <th class="sort border-top" data-sort="email">Numero</th>
                                <th class="sort border-top" data-sort="age">Date</th>
                                <th class="sort text-end align-middle pe-0 border-top" scope="col">ACTION</th>
                              </tr>
                            </thead>
                            <tbody class="list">

                            @foreach ($data as $datas)
                            <tr>
                                <td class="align-middle ps-3 name">{{ $datas->numero }}</td>
                                <td class="align-middle email">{{ $datas->titre }}</td>
                                <td class="align-middle age">{{ $datas->date }}</td>
                              
                                <td class="align-middle white-space-nowrap text-end pe-0">
                                  <div class="font-sans-serif btn-reveal-trigger position-static">
                                    <button class="btn btn-sm dropdown-toggle dropdown-caret-none transition-none btn-reveal fs--2" type="button" data-bs-toggle="dropdown" data-boundary="window" aria-haspopup="true" aria-expanded="false" data-bs-reference="parent"><svg class="svg-inline--fa fa-ellipsis fs--2" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="ellipsis" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg=""><path fill="currentColor" d="M120 256C120 286.9 94.93 312 64 312C33.07 312 8 286.9 8 256C8 225.1 33.07 200 64 200C94.93 200 120 225.1 120 256zM280 256C280 286.9 254.9 312 224 312C193.1 312 168 286.9 168 256C168 225.1 193.1 200 224 200C254.9 200 280 225.1 280 256zM328 256C328 225.1 353.1 200 384 200C414.9 200 440 225.1 440 256C440 286.9 414.9 312 384 312C353.1 312 328 286.9 328 256z"></path></svg><!-- <span class="fas fa-ellipsis-h fs--2"></span> Font Awesome fontawesome.com --></button>
                                    <div class="dropdown-menu dropdown-menu-end py-2"><a class="dropdown-item" href="#!">View</a><a class="dropdown-item" href="#!">Export</a>
                                      <div class="dropdown-divider"></div><a class="dropdown-item text-danger" href="#!">Remove</a>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            @endforeach

                              </tbody>
                          </table>
                        </div>
                        <div class="d-flex justify-content-center mt-3"><button class="page-link disabled" data-list-pagination="prev" disabled=""><svg class="svg-inline--fa fa-chevron-left" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-left" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" data-fa-i2svg=""><path fill="currentColor" d="M224 480c-8.188 0-16.38-3.125-22.62-9.375l-192-192c-12.5-12.5-12.5-32.75 0-45.25l192-192c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25L77.25 256l169.4 169.4c12.5 12.5 12.5 32.75 0 45.25C240.4 476.9 232.2 480 224 480z"></path></svg><!-- <span class="fas fa-chevron-left"></span> Font Awesome fontawesome.com --></button>
                          <ul class="mb-0 pagination"><li class="active"><button class="page" type="button" data-i="1" data-page="5">1</button></li><li><button class="page" type="button" data-i="2" data-page="5">2</button></li><li><button class="page" type="button" data-i="3" data-page="5">3</button></li><li class="disabled"><button class="page" type="button">...</button></li><li><button class="page" type="button" data-i="9" data-page="5">9</button></li></ul><button class="page-link pe-0" data-list-pagination="next"><svg class="svg-inline--fa fa-chevron-right" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" data-fa-i2svg=""><path fill="currentColor" d="M96 480c-8.188 0-16.38-3.125-22.62-9.375c-12.5-12.5-12.5-32.75 0-45.25L242.8 256L73.38 86.63c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0l192 192c12.5 12.5 12.5 32.75 0 45.25l-192 192C112.4 476.9 104.2 480 96 480z"></path></svg><!-- <span class="fas fa-chevron-right"></span> Font Awesome fontawesome.com --></button>
                        </div>
                      </div>
                    
        </div>
    </div>


    <script>
        $(function() {
            // Add PROJECT ajax 
            $("#addProjectForm").submit(function(e) {
                e.preventDefault();
                const fd = new FormData(this);
                $("#addProjectbtn").text('Adding...');
                $.ajax({
                    url: "{{ route('storeProject') }}",
                    method: 'post',
                    data: fd,
                    cache: false,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(response) {
                        if (response.status == 200) {
                            $.notify("You have Successfully add a project !", "success");
                        }
                        $("#addProjectbtn").text('Add Project');
                        $("#addProjectForm")[0].reset();
                    }
                });
            });


        });
    </script>

    @endsection