<!-- resources/views/error-page.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fichier non trouvé</title>
</head>
<body>
    <h1>Fichier non trouvé</h1>
    <p>Le fichier que vous essayez de consulter n'existe pas.</p>
</body>
</html>
