@include('layout/partiels/head')
    @yield('page-content')
@include('layout/partiels/foot')