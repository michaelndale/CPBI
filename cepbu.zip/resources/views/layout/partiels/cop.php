<button class="btn p-1" type="button" data-bs-dismiss="modal" aria-label="Close"><span class="fas fa-times fs--1"></span></button>

toastr.error('Une personnel n\'est peut avoir deux compte utilisateur.', 'Erreur');

toastr.info('L\'indetifiant utilisateur existe déjà .', 'Erreur');

toastr.success('Utilisateur enregitrer avec succes .', 'Enregitrement');

Auth::id();